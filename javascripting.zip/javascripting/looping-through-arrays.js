var pets = ['cat', 'dog', 'rat'];
for (i = 0; i < 3; i++){
	pets[i] = pets[i] + 's';
}
console.log(pets);