function math(luh, luhh, luhhh){
	return (luhh * luhhh) + luh;
}
console.log(math(53, 61, 67));