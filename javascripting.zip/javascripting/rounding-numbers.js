var roundUp = 1.5;
var rounded = Math.round(roundUp);
console.log(rounded);