function eat(food){
	return food + ' tasted really good.';
}
console.log(eat('bananas'));